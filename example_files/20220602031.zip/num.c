#include <stdio.h>

int main() {
    printf("Second c!\n");
    return 0;
}